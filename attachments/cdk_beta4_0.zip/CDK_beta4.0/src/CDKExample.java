import javax.swing.JFrame;

import org.genomespace.client.DataManagerClient;
import org.genomespace.client.AnalysisToolManagerClient;
import org.genomespace.atm.model.WebToolDescriptor;
import org.genomespace.client.ConfigurationUrls;
import org.genomespace.client.GsSession;
import org.genomespace.client.ui.GSLoginDialog;
import org.genomespace.datamanager.core.GSDirectoryListing;
import org.genomespace.datamanager.core.GSFileMetadata;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

/**
 * Example of using the CDK to login and list the files present
 * 
 * @author liefeld
 * 
 */
public class CDKExample {

	public static void main(String[] args) throws Exception {

		/**
		 * IMPORTANT:
		 * 
		 * ConfigurationUrls.init("test"); To use against production:
		 * ConfigurationUrls.init("prod")
		 * 
		 * prior to any login
		 */
		ConfigurationUrls.init("prod");

		final GSLoginDialog loginDialog = new GSLoginDialog();
		loginDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// skip login dialog showing if there is a cached session
		loginDialog.setVisible(true);

		if(loginDialog.getGsSession().isLoggedIn())loginDialog.getGsSession().logout();
		
		loginDialog.setPostLoginListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (loginDialog.getGsSession().isLoggedIn()) {
					System.out.println("Logged in now as " + loginDialog.getGsUser().getUsername()
							+ "\n\t files for this user in the DM are ...\n");
					GsSession session = loginDialog.getGsSession();
					DataManagerClient dmClient = session.getDataManagerClient();

					GSDirectoryListing dirList = dmClient.listDefaultDirectory();
					printDirectoryContents(dmClient, dirList, "");

					try {
						AnalysisToolManagerClient atmClient = session.getAnalysisToolManagerClient();
						List<WebToolDescriptor> tools = atmClient.getWebTools();
						for (WebToolDescriptor d : tools) {
							System.out.println("Tool = " + d.getName());
						}

					} catch (Exception ee) {
						ee.printStackTrace();
					}

				} else {
					System.out.println("Login failed");
				}

				System.exit(0);
			}

		});

		if (loginDialog.getGsSession().isLoggedIn()) {
			loginDialog.getPostLoginListener().actionPerformed(null);
			System.exit(0);
		}

		// System.exit(0);
	}

	/**
	 * recursively print the directory contents and also show links to the files
	 * 
	 * @param dmClient
	 * @param dirList
	 * @param prefix
	 */
	public static void printDirectoryContents(DataManagerClient dmClient, GSDirectoryListing dirList, String prefix) {
		System.out.println("");// blank line between directories
		for (GSFileMetadata aFile : dirList.findFiles()) {
			System.out.println(prefix + " / " + aFile.getName() + "\t\t\t" + dmClient.getFileUrl(aFile, null));
		}
		for (GSFileMetadata aDir : dirList.findDirectories()) {
			GSDirectoryListing subDir = dmClient.list(aDir);
			String subPrefix = prefix + " / " + aDir.getName();
			printDirectoryContents(dmClient, subDir, subPrefix);
		}
	}

}
